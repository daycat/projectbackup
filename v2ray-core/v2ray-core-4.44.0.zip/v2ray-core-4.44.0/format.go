package core

//go:generate go install -v github.com/daixiang0/gci@latest
//go:generate go run ./infra/vformat/
